/**
 * 
 */
package org.wltea.analyzer.test;

/**
 * @author linliangyi
 *
 */
public class NumberSegmenter {

}
